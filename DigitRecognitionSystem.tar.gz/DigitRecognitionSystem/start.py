from Tkinter import *
import Tkinter
from PIL import ImageTk, Image
from tkFileDialog import askopenfilename
from Knn import *
from Hog_SVM import *
from resizeimage import resizeimage

def KNNfileProcessing():
   B0.config(state='disabled',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
   B1.config(state='disabled',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
   status.config(text=" ")	
   flname = askopenfilename(parent=filewin)

   try:
		status.config(text="Processing.....")
		filewin.update_idletasks()
		filewin.update()
		img=cv2.imread(flname,-1)
		x=KNN()
		nsp=NumericStringParser()
		x.denoise(img)
		x.seperator()
		global str1,result
		str1=x.handWrittenDigitToString()
		result = nsp.eval(str1)
		status.config(text=" ")
		filewin.update_idletasks()
		filewin.update()
		originalImage(str1,result,flname)		
   except:
		B0.config(state='normal',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
		B1.config(state='normal',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
		status.config(text="OOPS!!!!!\nCHOOSE JPG IMAGE FROM FILE EXPLORER\nOR\nCAPTURE IMAGE FROM WEBCAM")	

def SVMfileProcessing():
   B0.config(state='disabled',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
   B1.config(state='disabled',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
   status.config(text=" ")
   flname = askopenfilename(parent=filewin)

   try: 
		status.config(text="Processing.....")
		filewin.update_idletasks()
		filewin.update()
		img=cv2.imread(flname,-1)
		x=Hog_SVM()
		nsp=NumericStringParser()
		x.training()
		x.denoise(img)
		x.seperator()
		global str1,result
		str1=x.handWrittenDigitToString()
		result = nsp.eval(str1)
		status.config(text=" ")
		filewin.update_idletasks()
		filewin.update()
		originalImage(str1,result,flname)		
   except:
		B0.config(state='normal',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
		B1.config(state='normal',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
		status.config(text="OOPS!!!!!\nCHOOSE JPG IMAGE FROM FILE EXPLORER\nOR\nCAPTURE IMAGE FROM WEBCAM")	
	

def fileProcessing():
   #B1.config(state='disabled',text ="Browse and Proceed",font=("Courier", 10,"bold"))
   
   #flname = askopenfilename(parent=filewin)
   try:
		status.config(text="Processing.....")
		filewin.update_idletasks()
		filewin.update()
		img=cv2.imread("capturedimage.jpg",-1)
		x=KNN()
		nsp=NumericStringParser()
		x.denoise(img)
		x.seperator()
		global str1,result
		str1=x.handWrittenDigitToString()
		result = nsp.eval(str1)
		status.config(text=" ")
		filewin.update_idletasks()
		filewin.update()
		originalImage(str1,result,"capturedimage.jpg")		
   except:
		B0.config(state='normal',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
		B1.config(state='normal',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
		status.config(text="OOPS!!!!!\nCHOOSE JPG IMAGE FROM FILE EXPLORER\nOR\nCAPTURE IMAGE FROM WEBCAM")	


def on_configure(event):
    # update scrollregion after starting 'mainloop'
    # when all widgets are in canvas
    canvas.configure(scrollregion=canvas.bbox('all'))    
   
def tokenizeImageShow(str1,result):
	middleframe3 = Frame(frame,padx=30,pady=30)
	middleframe3.pack()
	labelframe2 = LabelFrame(middleframe3,text="Tokenized Images")
	labelframe2.config(font=("Courier", 12,"bold"))
	labelframe2.pack(fill="both", expand="yes")
	path=os.getcwd()+'/digits'
	#print path
	ls=sorted(os.listdir(path))
	img1=[]
	for fl in ls:
		img = Image.open(path+"/"+fl)
		img = resizeimage.resize_contain(img, [100,100])
		img1.append(ImageTk.PhotoImage(img))
	for fl in range(len(ls)):
		#print fl
		picture1= Label(labelframe2, image = img1[fl])
		picture1.pack(side=LEFT)
	outputResult(str1,result)
	
def saltImage(str1,result):
	middleframe2 = Frame(frame,padx=30,pady=30)
	middleframe2.pack()
	labelframe1 = LabelFrame(middleframe2,text="Grayscale Image")
	labelframe1.config(font=("Courier", 12,"bold"))
	labelframe1.pack(fill="both", expand="yes")
	path=os.getcwd()
	img = Image.open(path+"/"+"salty.jpg")
	img = resizeimage.resize_contain(img, [500,300])
	img=ImageTk.PhotoImage(img)
	picture= Label(labelframe1, image = img)
	picture.pack(side=LEFT)	
	tokenizeImageShow(str1,result)
	
	
def originalImage(str1,result,flname):
	middleframe2 = Frame(frame,padx=30,pady=30)
	middleframe2.pack()
	labelframe1 = LabelFrame(middleframe2,text="Original Image")
	labelframe1.config(font=("Courier", 12,"bold"))
	labelframe1.pack(fill="both", expand="yes")
	path=os.getcwd()
	img = Image.open(flname)
	img = resizeimage.resize_contain(img, [500,300])
	img=ImageTk.PhotoImage(img)
	picture= Label(labelframe1, image = img)
	picture.pack(side=LEFT)	
	saltImage(str1,result)

def outputResult(str1,result):
	middleframe4 = Frame(frame,padx=30,pady=30)
	middleframe4.pack()
	labelframe3 = LabelFrame(middleframe4,text="Solution")
	labelframe3.config(font=("Courier", 12,"bold"))
	labelframe3.pack(fill="both", expand="yes")
	sten1="The String is "+str1
	sten2="The Result is "+str(result)
	label1= Label(labelframe3, text = sten1,padx=150)
	label1.config(font=("Courier", 15,"bold"))
	label1.pack()
	label2= Label(labelframe3, text = sten2,padx=150)
	label2.config(font=("Courier", 15,"bold"))
	label2.pack()	
	root.mainloop()
	

def close_windows():
        filewin.destroy()
        masterWindow()

def capture_image():
	B0.config(state='disabled',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
	B1.config(state='disabled',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
	status.config(text=" ")
	try:
		cap=cv2.VideoCapture(0)
		while True:
			ret,frame=cap.read()
			frame2=cv2.cvtColor(frame,0)
			cv2.imshow('CamCulator. Capture-ENTER, Back-ESC',frame2)
			statusLocal=False
			k=cv2.waitKey(1)& 0xFF
			if k == 27:	#ESC key
				break
			elif k == 10:  # ENTER Key
				statusLocal=True
				break
		cap.release()
		cv2.destroyAllWindows()
		cv2.waitKey(1)
		cv2.waitKey(1)
		cv2.waitKey(1)
		cv2.waitKey(1)

		if statusLocal:
			cv2.imwrite('capturedimage.jpg',frame2)
		fileProcessing()
	except:
		B0.config(state='normal',text ="Browse JPG Image and Proceed",font=("Courier", 10,"bold"))
		B1.config(state='normal',text ="Capture Image From Webcam",font=("Courier", 10,"bold"))
		status.config(text="OOPS!!!!!\nCHOOSE JPG IMAGE FROM FILE EXPLORER\nOR\nCAPTURE IMAGE FROM WEBCAM")
		
			

   
def KnnChildWindowinitialize():
	root.destroy()
	if os.path.exists('digits'):
		path=os.getcwd()+'/digits'
		for fl in os.listdir(path):
			#print fl
			os.remove(path+"/"+fl)
		os.rmdir(path)
	   
	global filewin
	global frame
	global canvas
	filewin = Tk()
	#filewin = Toplevel(root)
	filewin.title("KNN")
	
	canvas = Tkinter.Canvas(filewin,width=1285,height=700)
	canvas.pack(side=Tkinter.LEFT)

	scrollbar = Tkinter.Scrollbar(filewin, command=canvas.yview)
	scrollbar.pack(side=Tkinter.LEFT, fill='y')
	
	canvas.configure(yscrollcommand = scrollbar.set)

	canvas.bind('<Configure>', on_configure)

	frame = Tkinter.Frame(canvas)
	canvas.create_window((0,0), window=frame, anchor='nw')
	scrollbar = Scrollbar(filewin)
	scrollbar.pack( side = RIGHT, fill=Y )

	frame1 = Frame(frame)
	frame1.pack()

	middleframe1 = Frame(frame)
	middleframe1.pack()
	
	middleframe2 = Frame(frame)
	middleframe2.pack()

	bottomframe = Frame(frame)
	bottomframe.pack( side = BOTTOM )

	#m1 = PanedWindow(frame1)
	#m1.pack(fill=BOTH, expand=1)


	#m2 = PanedWindow(m1, orient=VERTICAL)
	#m1.add(m2)

	top = Label(frame1, text="K-NEAREST NEIGHBOR APPROACH",padx=300)
	top.config(font=("Courier", 24,"bold"),pady=50)
	#m2.add(top)
	top.pack(side=LEFT)
	B2 = Tkinter.Button(frame1, text ="Quit" ,command =close_windows ,font=("Courier", 13,"bold"),fg="red")
	B2.pack(side=LEFT)
	B2.config()
	#m2.add(B2)
	global B0
	B0 = Tkinter.Button(middleframe1, text ="Browse JPG Image and Proceed" ,command = KNNfileProcessing,font=("Courier", 10,"bold"))
	B0.pack(side=LEFT)
	label = Label(middleframe1, text="OR",padx=20)
	label.config(font=("Courier", 12,"bold"))
	label.pack(side=LEFT)
	global B1
	B1 = Tkinter.Button(middleframe1, text ="Capture Image From Webcam" ,command = capture_image, font=("Courier", 10,"bold"))
	#B1.config()
	B1.pack(side=LEFT)

	global status
	status = Label(middleframe2 ,font=("Courier", 15,"bold"),fg="red",pady=20)
	status.pack()

	footer = Label(bottomframe, text="Design by PSSSS",padx=300,pady=50)
	footer.config(font=("Courier", 10,"bold"))
	footer.pack(side = BOTTOM)
	filewin.mainloop()


def SVMChildWindowinitialize():
	root.destroy()
	if os.path.exists('digits'):
		path=os.getcwd()+'/digits'
		for fl in os.listdir(path):
			#print fl
			os.remove(path+"/"+fl)
		os.rmdir(path)
	   
	global filewin
	global frame
	global canvas
	filewin = Tk()
	#filewin = Toplevel(root)
	filewin.title("SVM")
	
	canvas = Tkinter.Canvas(filewin,width=1285,height=700)
	canvas.pack(side=Tkinter.LEFT)

	scrollbar = Tkinter.Scrollbar(filewin, command=canvas.yview)
	scrollbar.pack(side=Tkinter.LEFT, fill='y')
	
	canvas.configure(yscrollcommand = scrollbar.set)

	canvas.bind('<Configure>', on_configure)

	frame = Tkinter.Frame(canvas)
	canvas.create_window((0,0), window=frame, anchor='nw')
	scrollbar = Scrollbar(filewin)
	scrollbar.pack( side = RIGHT, fill=Y )

	frame1 = Frame(frame)
	frame1.pack()

	middleframe1 = Frame(frame)
	middleframe1.pack()

	middleframe2 = Frame(frame)
	middleframe2.pack()
	
	bottomframe = Frame(frame)
	bottomframe.pack( side = BOTTOM )

	#m1 = PanedWindow(frame1)
	#m1.pack(fill=BOTH, expand=1)


	#m2 = PanedWindow(m1, orient=VERTICAL)
	#m1.add(m2)

	top = Label(frame1, text="SUPPORT VECTOR MACHINE APPROACH",padx=300)
	top.config(font=("Courier", 24,"bold"),pady=50)
	#m2.add(top)
	top.pack(side=LEFT)
	B2 = Tkinter.Button(frame1, text ="Quit" ,command =close_windows ,font=("Courier", 13,"bold"),fg="red")
	B2.pack(side=LEFT)
	B2.config()
	#m2.add(B2)
	global B0
	B0 = Tkinter.Button(middleframe1, text ="Browse JPG Image and Proceed" ,command = SVMfileProcessing,font=("Courier", 10,"bold"))
	B0.pack(side=LEFT)
	label = Label(middleframe1, text="OR",padx=20)
	label.config(font=("Courier", 12,"bold"))
	label.pack(side=LEFT)
	global B1
	B1 = Tkinter.Button(middleframe1, text ="Capture Image From Webcam" ,command = capture_image, font=("Courier", 10,"bold"))
	#B1.config()
	B1.pack(side=LEFT)

	global status
	status = Label(middleframe2 ,pady=20,font=("Courier", 15,"bold"),fg="red")
	status.pack()

	footer = Label(bottomframe, text="Design by PSSSS",padx=300,pady=50)
	footer.config(font=("Courier", 10,"bold"))
	footer.pack(side = BOTTOM)
	filewin.mainloop()

	
def masterWindow():	
	global root	
	root = Tk()
	root.title("CamCulator")
	w, h = root.winfo_screenwidth(), root.winfo_screenheight()
	root.geometry("%dx%d+0+0" % (w, h))

	frame = Frame(root)
	frame.pack()

	bottomframe = Frame(root)
	bottomframe.pack( side = BOTTOM )

	m1 = PanedWindow(frame)
	m1.pack(fill=BOTH, expand=1)


	m2 = PanedWindow(m1, orient=VERTICAL)
	m1.add(m2)

	top = Label(m2, text="WELCOME TO HANDWRITTEN NUMERIC EXPRESSION RECOGNITION AND EVALUATION SYSTEM",padx="300",pady="50")
	top.config(font=("Courier", 20,"bold"))
	m2.add(top)
	bottom = Label(m2, text="SELECT CHOICE OF YOUR ALGORITHM",padx="300",pady="20")
	bottom.config(font=("Courier", 16,"bold"))
	m2.add(bottom)

	var = IntVar()
	R1 = Radiobutton( text="KNN",variable=var, value=1,command=KnnChildWindowinitialize,pady="20",font=("Courier", 10,"bold"))
	R1.pack()

	R2 = Radiobutton(text="SVM",variable=var, value=2,command=SVMChildWindowinitialize,pady="20",font=("Courier", 10,"bold"))
	R2.pack()
	m3 = PanedWindow(m2, orient=VERTICAL)
	m2.add(m3)
	footer = Label(bottomframe, text="Design by PSSSS",padx="300",pady="50")
	footer.config(font=("Courier", 10,"bold"))
	footer.pack(side = BOTTOM)
	#root.attributes('-fullscreen', True)
	#root.resizable(width=False, height=False)
	# Code to add widgets will go here...
	#root.geometry('{}x{}'.format(1300, 500))
	
	root.mainloop()

masterWindow()
