import numpy as np
import cv2
import os
from pyparsing import *
import math
import operator
from sklearn.externals import joblib
from skimage.feature import hog
from sklearn.svm import LinearSVC

class Hog_SVM():

	def training(self):

		if(not os.path.exists('all_digit_classifier.pkl')):
			print 'Classifier does not exist. Building the classifier......'
			hog_features=[]
			labels=[]

			for i in range(10):
				path='./Training Data/data'+str(i)
				f = open(path, "r")

				for j in range(1000):
					arr=np.fromfile(f,'B',784)
					arr=np.reshape(arr,(28,28))
					tshd_val,img=cv2.threshold(arr,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
					#print tshd_val
					hogf=hog(img,orientations=9, pixels_per_cell=(4, 4), cells_per_block=(2, 2), visualise=False)
					hog_features.append(hogf)

					labels.append(i)

				f.close()

			path='./Training Data/Operators/Plus-'

			for i in range(1,12):
				fp=path+str(i)+'.jpg'
				img = cv2.imread(fp,0)
				tval,thresh=cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
				hogf=hog(thresh,orientations=9, pixels_per_cell=(4, 4), cells_per_block=(2, 2), visualise=False)
				hog_features.append(hogf)
				labels.append(11)
			
			path='./Training Data/Operators/Multiplication-'

			for i in range(1,8):
				fp=path+str(i)+'.jpg'
				img = cv2.imread(fp,0)
				tval,thresh=cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
				hogf=hog(thresh,orientations=9, pixels_per_cell=(4, 4), cells_per_block=(2, 2), visualise=False)
				hog_features.append(hogf)
				labels.append(12)

			path='./Training Data/Operators/Division-'

			for i in range(1,15):
				fp=path+str(i)+'.jpg'
				img = cv2.imread(fp,0)
				tval,thresh=cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
				hogf=hog(thresh,orientations=9, pixels_per_cell=(4, 4), cells_per_block=(2, 2), visualise=False)
				hog_features.append(hogf)
				labels.append(13)

			path='./Training Data/Operators/Minus-'

			for i in range(1,10):
				fp=path+str(i)+'.jpg'
				img = cv2.imread(fp,0)
				tval,thresh=cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
				hogf=hog(thresh,orientations=9, pixels_per_cell=(4, 4), cells_per_block=(2, 2), visualise=False)
				hog_features.append(hogf)
				labels.append(14)


			hog_features=np.array(hog_features,'float64')
			labels=np.array(labels,'int')

			print hog_features.shape
			print labels.shape

			# Create an linear SVM object
			clf = LinearSVC()

			# Perform the training
			clf.fit(hog_features, labels)

			# Save the classifier
			joblib.dump(clf, "all_digit_classifier.pkl", compress=3)

		else:
			print 'Classifier exists. Prediction starts....'
		
		

	def predict(self,clf):
		img=cv2.imread('test-image-contain.jpg',0)
		tval,thresh=cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
		roi_hog_fd = hog(thresh, orientations=9, pixels_per_cell=(4, 4), cells_per_block=(2, 2), visualise=False)
			
		nbr = clf.predict(np.array([roi_hog_fd], 'float64'))
						
		return int(nbr)
	
	def resizePicture(self,s):
		img= cv2.imread(s,-1)
		img = cv2.resize(img,(28, 28), interpolation = cv2.INTER_CUBIC)
		cv2.imwrite('test-image-contain.jpg',img)
	
	def denoise(self,img):
		img = cv2.resize(img,(600, 600), interpolation = cv2.INTER_CUBIC)
		img = cv2.medianBlur(img,5)
		kernel_sharpen_1 = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
		output_1 = cv2.filter2D(img, -1, kernel_sharpen_1)
		img = cv2.fastNlMeansDenoisingColored(output_1,None,10,10,7,21)
		img = cv2.medianBlur(img,5)
		gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
		thresh = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
		bw = cv2.bitwise_not(thresh)
		kernel = np.ones((5,5),np.uint8)
		bw = cv2.bilateralFilter(bw,9,75,75)
		bw = cv2.medianBlur(bw,5)
		bw = cv2.medianBlur(bw,5)
		cv2.imwrite('salty.jpg',bw)
	
	def seperator(self):
		if not os.path.exists('digits'):
			os.makedirs('digits')
		path=os.getcwd()+'/digits'
		fn = "salty.jpg" 
		I=cv2.imread(fn)
		size = np.shape(I)
		if size[0]*size[1] > 3600:
			I = cv2.resize(I,(600, 600), interpolation = cv2.INTER_CUBIC)
		img=cv2.cvtColor(I,cv2.COLOR_BGR2GRAY)
		thresh = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
		img = cv2.bitwise_not(thresh)
		contours,hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		i=0
		x1=[]
		y1=[]
		for cnt in contours:
			x,y,w,h = cv2.boundingRect(cnt)
			x1.append(x)
		y1=list(x1)
		x1.sort()
		for i in range(len(x1)):
			for j in range(len(y1)):
				if(x1[i]==y1[j]):
					x,y,w,h = cv2.boundingRect(contours[j])
					dig= I[y:y+h,x:x+w]
					cv2.imwrite(path+'/digit'+ str(i) +'.jpg',dig)
					cv2.rectangle(I,(x,y),(x+w,y+h),(0,255,0),2)

			
	def handWrittenDigitToString(self):
		path=os.getcwd()+'/digits'
		ls=sorted(os.listdir(path))
		#print ls
		clf = joblib.load("all_digit_classifier.pkl")
		strn=''
		x1=Hog_SVM()
		for fl in ls:
			#print fl
			x1.resizePicture(path+'/'+fl)
			digit=x1.predict(clf)
			if(digit==11):
				strn+='+'
			elif(digit==12):
				strn+='*'
			elif(digit==13):
				strn+='/'
			elif(digit==14):
				strn+='-'
			else:
				strn+=str(digit)
		return strn



		
class NumericStringParser():
	
	
    def pushFirst(self, strg, loc, toks):
        self.exprStack.append(toks[0])

    def pushUMinus(self, strg, loc, toks):
        if toks and toks[0] == '-':
            self.exprStack.append('unary -')
	
    def __init__(self):
        point = Literal(".")
        e = CaselessLiteral("E")
        fnumber = Combine(Word("+-" + nums, nums) +
                          Optional(point + Optional(Word(nums))) +
                          Optional(e + Word("+-" + nums, nums)))
        ident = Word(alphas, alphas + nums + "_$")
        plus = Literal("+")
        minus = Literal("-")
        mult = Literal("*")
        div = Literal("/")
        lpar = Literal("(").suppress()
        rpar = Literal(")").suppress()
        addop = plus | minus
        multop = mult | div
        expop = Literal("^")
        pi = CaselessLiteral("PI")
        expr = Forward()
        atom = ((Optional(oneOf("- +")) +
                 (ident + lpar + expr + rpar | pi | e | fnumber).setParseAction(self.pushFirst))
                | Optional(oneOf("- +")) + Group(lpar + expr + rpar)
                ).setParseAction(self.pushUMinus)
        
        factor = Forward()
        factor << atom + \
            ZeroOrMore((expop + factor).setParseAction(self.pushFirst))
        term = factor + \
            ZeroOrMore((multop + factor).setParseAction(self.pushFirst))
        expr << term + \
            ZeroOrMore((addop + term).setParseAction(self.pushFirst))
        self.bnf = expr
        epsilon = 1e-12
        self.opn = {"+": operator.add,
                    "-": operator.sub,
                    "*": operator.mul,
                    "/": operator.truediv,
                    "^": operator.pow}
        
    def evaluateStack(self, s):
        op = s.pop()
        if op in "+-*/^":
            op2 = self.evaluateStack(s)
            op1 = self.evaluateStack(s)
            return self.opn[op](op1, op2)
        
        if op[0].isalpha():
            return 0
        
        else:
            return float(op)
        

    def eval(self, num_string, parseAll=True):
        self.exprStack = []
       
        results = self.bnf.parseString(num_string, parseAll)
        print results
        val = self.evaluateStack(self.exprStack[:])
        return val