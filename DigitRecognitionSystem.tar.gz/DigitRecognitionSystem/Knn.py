import numpy as np
import cv2
import os
from pyparsing import *
import math
import operator
class KNN():
	def fileGenerator(self):
		path=os.getcwd()
		path=path+'/mnist_png/training'
		print path
		ls=sorted(os.listdir(path))
		print ls
		a=0
		x=[]
		y=[]
		for fd in ls:
			a=a+len(os.listdir(path+'/'+str(fd)))
			print fd
			print 'started'
			for fl in os.listdir(path+'/'+str(fd)):
				img = cv2.imread(path+'/'+fd+'/'+fl,-1)
				m=img[ : ].reshape(1,784).astype(np.float32)
				x=np.append(x,m).astype(np.float32)
				z=np.array(fd)
				y=np.append(y,z).astype(np.int32)
			print 'end'
		train=np.hsplit(x,a)
		train_labels = y[:,np.newaxis]
		print train_labels
		print 'writing started'
		np.savez('knn_data.npz',train=train, train_labels=train_labels)
		print 'writing end'
	
	def training(self):
		if(not os.path.exists('knn_data.npz')):
			print 'not exist'
			x=KNN()
			x.fileGenerator()
		if(os.path.exists('knn_data.npz')):
			with np.load('knn_data.npz') as data:
				global knn
				knn = cv2.KNearest()
				train = data['train']
				train_labels = data['train_labels']
				knn.train(train,train_labels)
		
		
	def testing(self):
		img_test = cv2.imread('test-image-contain.jpg',cv2.IMREAD_GRAYSCALE)
		im_bw1 =img_test[ : ].reshape(1,784).astype(np.float32)
		ret,result,neighbours,dist = knn.find_nearest(im_bw1,k=7)
		print ret
		print neighbours
		print dist	
		return int(ret)
	
	def resizePicture(self, s):
		img= cv2.imread(s,-1)
		img = cv2.resize(img,(28, 28), interpolation = cv2.INTER_CUBIC)
		cv2.imwrite('test-image-contain.jpg',img)
	
	def denoise(self,img):
		img = cv2.resize(img,(600, 600), interpolation = cv2.INTER_CUBIC)
		img = cv2.medianBlur(img,5)
		kernel_sharpen_1 = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
		output_1 = cv2.filter2D(img, -1, kernel_sharpen_1)
		img = cv2.fastNlMeansDenoisingColored(output_1,None,10,10,7,21)
		img = cv2.medianBlur(img,5)
		gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
		thresh = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
		bw = cv2.bitwise_not(thresh)
		kernel = np.ones((5,5),np.uint8)
		bw = cv2.bilateralFilter(bw,9,75,75)
		bw = cv2.medianBlur(bw,5)
		bw = cv2.medianBlur(bw,5)
		cv2.imwrite('salty.jpg',bw)
	
	def seperator(self):
		if not os.path.exists('digits'):
			os.makedirs('digits')
		path=os.getcwd()+'/digits'
		fn = "salty.jpg" 
		I=cv2.imread(fn)
		size = np.shape(I)
		if size[0]*size[1] > 3600:
			I = cv2.resize(I,(600, 600), interpolation = cv2.INTER_CUBIC)
		img=cv2.cvtColor(I,cv2.COLOR_BGR2GRAY)
		thresh = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
		img = cv2.bitwise_not(thresh)
		contours,hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		i=0
		x1=[]
		y1=[]
		for cnt in contours:
			x,y,w,h = cv2.boundingRect(cnt)
			x1.append(x)
		y1=list(x1)
		x1.sort()
		for i in range(len(x1)):
			for j in range(len(y1)):
				if(x1[i]==y1[j]):
					x,y,w,h = cv2.boundingRect(contours[j])
					dig= I[y:y+h,x:x+w]
					cv2.imwrite(path+'/digit'+ str(i) +'.jpg',dig)
					cv2.rectangle(I,(x,y),(x+w,y+h),(0,255,0),2)		
		
		
	def handWrittenDigitToString(self):
		path=os.getcwd()+'/digits'
		ls=sorted(os.listdir(path))
		#print ls
		strn=''
		x1=KNN()
		x1.training()
		for fl in ls:
			#print fl
			x1.resizePicture(path+'/'+fl)
			digit=x1.testing()
			if(digit==11):
				strn+='+'
			elif(digit==12):
				strn+='*'
			elif(digit==13):
				strn+='/'
			elif(digit==14):
				strn+='-'
			else:
				strn+=str(digit)
		return strn



		
class NumericStringParser():
	
	
    def pushFirst(self, strg, loc, toks):
        self.exprStack.append(toks[0])

    def pushUMinus(self, strg, loc, toks):
        if toks and toks[0] == '-':
            self.exprStack.append('unary -')
	
    def __init__(self):
        point = Literal(".")
        e = CaselessLiteral("E")
        fnumber = Combine(Word("+-" + nums, nums) +
                          Optional(point + Optional(Word(nums))) +
                          Optional(e + Word("+-" + nums, nums)))
        ident = Word(alphas, alphas + nums + "_$")
        plus = Literal("+")
        minus = Literal("-")
        mult = Literal("*")
        div = Literal("/")
        lpar = Literal("(").suppress()
        rpar = Literal(")").suppress()
        addop = plus | minus
        multop = mult | div
        expop = Literal("^")
        pi = CaselessLiteral("PI")
        expr = Forward()
        atom = ((Optional(oneOf("- +")) +
                 (ident + lpar + expr + rpar | pi | e | fnumber).setParseAction(self.pushFirst))
                | Optional(oneOf("- +")) + Group(lpar + expr + rpar)
                ).setParseAction(self.pushUMinus)
        
        factor = Forward()
        factor << atom + \
            ZeroOrMore((expop + factor).setParseAction(self.pushFirst))
        term = factor + \
            ZeroOrMore((multop + factor).setParseAction(self.pushFirst))
        expr << term + \
            ZeroOrMore((addop + term).setParseAction(self.pushFirst))
        self.bnf = expr
        epsilon = 1e-12
        self.opn = {"+": operator.add,
                    "-": operator.sub,
                    "*": operator.mul,
                    "/": operator.truediv,
                    "^": operator.pow}
        
    def evaluateStack(self, s):
        op = s.pop()
        if op in "+-*/^":
            op2 = self.evaluateStack(s)
            op1 = self.evaluateStack(s)
            return self.opn[op](op1, op2)
        
        if op[0].isalpha():
            return 0
        
        else:
            return float(op)
        

    def eval(self, num_string, parseAll=True):
        self.exprStack = []
       
        results = self.bnf.parseString(num_string, parseAll)
        print results
        val = self.evaluateStack(self.exprStack[:])
        return val
        
			
		

